-- ******************************************** --
-- * GROUPE APIY                                --
-- * DATE 11/02/21                              -- 
-- * MISSION 6                                  --
-- ******************************************** --
-- * ENVIRONNEMENT                              --
-- * phpMyAdmin ver 5.0.2                       --
-- * MySQL ver 5.7.31                           --
-- * OS: Win10, Nav : Chrome                    --
-- ******************************************** --
-- * IMPLEMENTATION BDD VIDEOSTAR               --
-- * Insertion dans les tables                  --
-- ******************************************** --

use videostar;

-- Ajout dans la table adherents
INSERT INTO adherents (id_adherent,numero_adherent, civilite, nom, prenom, adresse,ville, code_postal, tel, email, credits_restant)
	VALUES
		(NULL,'AD0963458','MME','DUCLO','SIMONE','8 RUE DU PRE','ST PRIEST SOUS AIXE','87700','0587463145','simone.DUCLO@gmail.com',120),
		(NULL,'AD0963463','MLLE','VERGO','JUSTINE','12 RUE DE OLIVADES','ETIGNY','89510','0563659214','justine.VERGO@gmail.com',33),
		(NULL,'AD0963464','M','PRUNEL','FREDERIC','65 CHEMIN BONFANTE','JORXEY','88500','0582546975','frederic.PRUNEL@gmail.com',68),
		(NULL,'AD0963466','M','AXSON','NICOLAS','97 RUE HONORE POURCHIER','GILLEY','52500','0165324652','nicolas.AXSON@gmail.com',47),
		(NULL,'AD0963474','M','DESCHAMPS','PHIL','3 TRAVERSE RICHARD','DUZEY','55230','0547896314','phil.DESCHAMPS@gmail.com',45),
		(NULL,'AD0963479','M','RICHARD','DANY','1 RUE CLINCHAMP','RECICOURT','55120','0595857412','dany.RICHARD@gmail.com',96)
;
-- Ajout dans la table categories
INSERT INTO categories (libelle) 
	VALUES 
        ('New')
;
-- Ajout dans la table supports_physiques
INSERT INTO supports_physiques (libelle, prix_location_journalier) 
	VALUES 
        ('DVD',3),
        ('BLU-RAY',4)
;
-- Film - Interstellar
INSERT INTO documentaires (id_documentaire,code_documentaire,libelle,annee,telechargeable,prix_telechargement,id_categorie)
    VALUES
		(NULL,'INTSTL','Interstellar',2014,1,5,LAST_INSERT_ID())
;
INSERT INTO exemplaires (id_exemplaire,numero_exemplaire,etat,id_documentaire,id_support_physique)
	VALUES
		(NULL,'INTSTL01','E',LAST_INSERT_ID(),1),
		(NULL,'INTSTL02','L',LAST_INSERT_ID(),1),
		(NULL,'INTSTL03','E',LAST_INSERT_ID(),2),
		(NULL,'INTSTL04','L',LAST_INSERT_ID(),2)
;
INSERT INTO stars (nom,prenom)
    VALUES
        ('McConaughey','Matthew')
;
INSERT INTO  participer (id_documentaire,id_star,role)
	VALUES
		(LAST_INSERT_ID(),LAST_INSERT_ID(),'Acteur')
;
INSERT INTO stars (nom,prenom)
    VALUES
        ('Hathaway','Anne')
;
INSERT INTO  participer (id_documentaire,id_star,role)
	VALUES
		(LAST_INSERT_ID(),LAST_INSERT_ID(),'Actrice')
;
INSERT INTO stars (nom,prenom)
    VALUES
        ('Nolan','Christopher')
;
INSERT INTO  participer (id_documentaire,id_star,role)
	VALUES
		(LAST_INSERT_ID(),LAST_INSERT_ID(),'Realisateur')
;
INSERT INTO lieux (nom)
	VALUES 
        ('Etats-Unis')
;
INSERT INTO localiser (id_documentaire,id_lieux)
	VALUES 
        (LAST_INSERT_ID(),LAST_INSERT_ID())
;
-- Film - Inception

INSERT INTO documentaires (id_documentaire,code_documentaire,libelle,annee,telechargeable,prix_telechargement,id_categorie)
    VALUES
		(NULL,'INCEPT','Inception',2010,1,5,LAST_INSERT_ID())
;
INSERT INTO exemplaires (id_exemplaire,numero_exemplaire,etat,id_documentaire,id_support_physique)
	VALUES
		(NULL,'INCEPT01','E',LAST_INSERT_ID(),1),
		(NULL,'INCEPT02','L',LAST_INSERT_ID(),1),
		(NULL,'INCEPT03','E',LAST_INSERT_ID(),2),
		(NULL,'INCEPT04','L',LAST_INSERT_ID(),2)
;
INSERT INTO stars (nom,prenom)
    VALUES
        ('DiCaprio','Leonardo')
;
INSERT INTO  participer (id_documentaire,id_star,role)
	VALUES
		(LAST_INSERT_ID(),LAST_INSERT_ID(),'Acteur')
;
INSERT INTO stars (nom,prenom)
    VALUES
        ('Hardy','Tom')
;
INSERT INTO  participer (id_documentaire,id_star,role)
	VALUES
		(LAST_INSERT_ID(),LAST_INSERT_ID(),'Acteur')
;
INSERT INTO stars (nom,prenom)
    VALUES
        ('Nolan','Christopher')
;
INSERT INTO  participer (id_documentaire,id_star,role)
	VALUES
		(LAST_INSERT_ID(),LAST_INSERT_ID(),'Realisateur')
;

INSERT INTO localiser (id_documentaire,id_lieux)
	VALUES 
        (LAST_INSERT_ID(),LAST_INSERT_ID())
;
-- Film - Avengers
INSERT INTO documentaires (id_documentaire,code_documentaire,libelle,annee,telechargeable,prix_telechargement,id_categorie)
    VALUES
		(NULL,'AVGRS1','Avengers',2012,1,5,LAST_INSERT_ID())
;
INSERT INTO exemplaires (id_exemplaire,numero_exemplaire,etat,id_documentaire,id_support_physique)
	VALUES
		(NULL,'AVGRS101','E',LAST_INSERT_ID(),1),
		(NULL,'AVGRS102','L',LAST_INSERT_ID(),1),
		(NULL,'AVGRS103','E',LAST_INSERT_ID(),2),
		(NULL,'AVGRS104','L',LAST_INSERT_ID(),2)
;
INSERT INTO stars (nom,prenom)
    VALUES
        ('Downey Jr','Robert')
;
INSERT INTO  participer (id_documentaire,id_star,role)
	VALUES
		(LAST_INSERT_ID(),LAST_INSERT_ID(),'Acteur')
;
INSERT INTO stars (nom,prenom)
    VALUES
        ('Johansson','Scarlett')
;
INSERT INTO  participer (id_documentaire,id_star,role)
	VALUES
		(LAST_INSERT_ID(),LAST_INSERT_ID(),'Actrice')
;
INSERT INTO stars (nom,prenom)
    VALUES
        ('Whedon','Joss')
;
INSERT INTO  participer (id_documentaire,id_star,role)
	VALUES
		(LAST_INSERT_ID(),LAST_INSERT_ID(),'Realisateur')
;

INSERT INTO localiser (id_documentaire,id_lieux)
	VALUES 
        (LAST_INSERT_ID(),LAST_INSERT_ID())
;
-- Film - John Wick 1
INSERT INTO documentaires (id_documentaire,code_documentaire,libelle,annee,telechargeable,prix_telechargement,id_categorie)
    VALUES
		(NULL,'JONWI1','John Wick 1',2014,1,5,LAST_INSERT_ID())
;
INSERT INTO exemplaires (id_exemplaire,numero_exemplaire,etat,id_documentaire,id_support_physique)
	VALUES
		(NULL,'JONWI101','E',LAST_INSERT_ID(),1),
		(NULL,'JONWI102','L',LAST_INSERT_ID(),1),
		(NULL,'JONWI103','E',LAST_INSERT_ID(),2),
		(NULL,'JONWI104','L',LAST_INSERT_ID(),2)
;
INSERT INTO stars (nom,prenom)
    VALUES
        ('Reeves','Keanu')
;
INSERT INTO  participer (id_documentaire,id_star,role)
	VALUES
		(LAST_INSERT_ID(),LAST_INSERT_ID(),'Acteur')
;

INSERT INTO stars (nom,prenom)
    VALUES
        ('Fishburne','Laurence')
;
INSERT INTO  participer (id_documentaire,id_star,role)
	VALUES
		(LAST_INSERT_ID(),LAST_INSERT_ID(),'Acteur')
;
INSERT INTO stars (nom,prenom)
    VALUES
        ('Stahelski','Chad')
;
INSERT INTO  participer (id_documentaire,id_star,role)
	VALUES
		(LAST_INSERT_ID(),LAST_INSERT_ID(),'Realisateur')
;

INSERT INTO localiser (id_documentaire,id_lieux)
	VALUES 
        (LAST_INSERT_ID(),LAST_INSERT_ID())
;
-- Ajout dans la table lieux
INSERT INTO lieux (nom)
	VALUES 
        ('Paris'),
        ('New-York'),
        ('Londre'),
        ('Angleterre')
;
-- Ajout dans la table categories
INSERT INTO categories (libelle) 
	VALUES 
        ('Science-Fiction'),
        ('Espionnage'),
        ('Action'),
        ('Aventure'),
        ('Documentaire'),
        ('Frisson'),
        ('Fantastique')
;
