-- ******************************************** --
-- * GROUPE APIY                                --
-- * DATE 11/02/21                              -- 
-- * MISSION 6                                  --
-- ******************************************** --
-- * ENVIRONNEMENT                              --
-- * phpMyAdmin ver 5.0.2                       --
-- * MySQL ver 5.7.31                           --
-- * OS: Win10, Nav : Chrome                    --
-- ******************************************** --
-- * IMPLEMENTATION BDD VIDEOSTAR               --
-- * Insertion dans les tables                  --
-- ******************************************** --

use videostar;

INSERT INTO lieux (nom)
	VALUES 
        ('Paris'),
        ('New-York'),
        ('Washington'),
        ('Marseille'),
        ('Los-Angeles'),
        ('Lyon'),
        ('Chicago'),
        ('Londre'),
        ('Berlin'),
        ('Etats-Unis'),
        ('Angleterre')
;

INSERT INTO categories (libelle) 
	VALUES 
        ('new'),
        ('science-fiction'),
        ('policier'),
        ('thriller'),
        ('comédie'),
        ('action'),
        ('aventure'),
        ('documentaire'),
        ('frisson'),
        ('animation'),
        ('biopic'),
        ('drame'),
        ('fantastique'),
        ('peplum')
;

INSERT INTO supports_physiques (libelle, prix_location_journalier) 
	VALUES 
        ('DVD',3),
        ('BLU-RAY',4)
;

INSERT INTO stars (prenom,nom)
    VALUES
		('Matthew','McConaughey'),
		('Hathaway','Anne'),
		('DiCaprio','Leonardo'),
		('Hardy','Tom'),
		('Downey Jr','Robert'),
		('Johansson','Scarlett'),
		('Reeves','Keanu'),
		('Fishburne','Laurence'),
		('Nolan','Christopher'),
		('Whedon','Joss'),
		('Stahelski','Chad')
;

INSERT INTO documentaires (code_documentaire,libelle,annee,telechargeable,prix_telechargement)
    VALUES
		('INTSTL','Interstellar',2014,1,5),
		('INCEPT','Inception',2010,1,5),
		('AVGRS1','Avengers',2012,1,5),
		('JONWI1','John Wick 1',2014,1,5)
;

INSERT INTO adherents (numero_adherent, civilite, nom, prenom, adresse,ville, code_postal, tel, email, credits_restant)
	VALUES
		('AD0963458','MME','DUCLO','SIMONE','8 RUE DU PRE','ST PRIEST SOUS AIXE','87700','0587463145','simone.DUCLO@gmail.com',120),
		('AD0963459','M','VERIN','STEPHANE','122 RUE DU SAVRE','ST HILAIRE LES PLACES','87800','0536543247','stephane.VERIN@gmail.com',5),
		('AD0963460','M','LEMOINE','LAURENT','14 RUE DE MONSERRAT','LA ROCHE LABEILLE','87800','0596579212','laurent.LEMOINE@gmail.com',34),
		('AD0963461','MME','DUPRE','SIMONE','154 BOULEVARD CHATEAUVALLON','ST MAURICE SUR MOSELLE','88560','0476521589','simone.DUPRE@gmail.com',124),
		('AD0963462','M','	LEPINE','ADRIEN','43 RUE AMIRAL CELLIER','CHAMP LE DUC','88600','0548745472','adrien.LEPINE@gmail.com',21),
		('AD0963463','MLLE','VERGO','JUSTINE','12 RUE DE OLIVADES','ETIGNY','89510','0563659214','justine.VERGO@gmail.com',33),
		('AD0963464','M','PRUNEL','FREDERIC','65 CHEMIN BONFANTE','JORXEY','88500','0582546975','frederic.PRUNEL@gmail.com',68),
		('AD0963465','MLLE','ABSIS','AGNES','8 AVENUE CHARLES GANTELME','REMICOURT','88500','0556986365','agnes.ABSIS@gmail.com',97),
		('AD0963466','M','AXSON','NICOLAS','97 RUE HONORE POURCHIER','GILLEY','52500','0165324652','nicolas.AXSON@gmail.com',47),
		('AD0963467','MLLE','DESCHAMPS','CORINE','107 AVENUE SYLVAIN THURIN','GAHARD','35490','0145215874','corine.DESCHAMPS@gmail.com',88),
		('AD0963468','MME','ALONZO','AGNES','3 RUE CHAMPOLLION','PUITS LA VALLEE','60480','0213265425','agnes.ALONZO@gmail.com',65),
		('AD0963469','M','FERRY','VINCENT','69 TRAVERSE JAINE','AMBERIEU EN BUGEY','01500','0152326536','vincent.FERRY@gmail.com',47),
		('AD0963470','M','LAROUSSE','ROBERT','225 AVENUE CHIARISOLI BEY','GIMEL LES CASCADES','19800','0195154256','robert.LAROUSSE@gmail.com',100),
		('AD0963471','M','HAMILTON','LEWIS','17 AVENUE ANDRE LE CHATELIER','GIMEL LES CASCADES','19800','0195185647','lewis.HAMILTON@gmail.com',98),
		('AD0963472','M','GROSJEAN','ROMAIN','6 IMPASSE PEROT','CESSEY SUR TILLE','21110','0254784573','romain.GROSJEAN@gmail.com',64),
		('AD0963473','M','MARTIN','DOCK','107 AVENUE COMMANDANT BERNARD','CRECEY SUR TILLE','21120','0254784539','dock.MARTIN@gmail.com',72),
		('AD0963474','M','DESCHAMPS','PHIL','3 TRAVERSE RICHARD','DUZEY','55230','0547896314','phil.DESCHAMPS@gmail.com',45),
		('AD0963475','M',' PREVERT','JEAN','48 CHEMIN DE LA POUDRIERE','FONTAINES ST CLAIR','55110','0527398465','jean.PREVERT@gmail.com',98),
		('AD0963476','MME','HUGO','VERONIQUE','304 RUE CANROBERT',' LES TROIS DOMAINES','55220','0542365658','veronique.HUGO@gmail.com',36),
		('AD0963477','M','VETEL','SEB','62 RUE EDMON HARANCOURT','LAMORVILLE','55300','0598746589','seb.VETEL@gmail.com',47),
		('AD0963478','M','BOTTAS','VAL','107 PLACE MARIUS CHAMPAGNE','MARSON SUR BARBOURE','55190','0514237845','val.BOTTAS@gmail.com',98),
		('AD0963479','M','RICHARD','DANY','1 RUE CLINCHAMP','RECICOURT','55120','0595857412','dany.RICHARD@gmail.com',96),
		('AD0963480','M','PEREZ','SERGE','59 AVENUE PIERRE RENAUDEL	LES SOUHESMES',' RAMPONT','55220','0568362335','serge.PEREZ@gmail.com',25),
		('AD0963481','M','NORRIS','LAURENT','307 AVENUE JEAN RAMBAUD','TREFLEZ','29430','0248755699','laurent.NORRIS@gmail.com',37),
		('AD0963482','M','TROCON','SEB','5 IMPASSE ESTAMPE','ST MARTIN DE VALGALGUES','30520','0224155478','seb.TROCON@gmail.com',12),
		('AD0963483','MME','ALONZO','JUSTINE','97 LES PEPINIERES DU LAS','BOEGE','74420','0588614937','justine.ALONZO@gmail.com',3),
		('AD0963484','M','ABSIS','SERGE','8 LES PRIMEROSES','MONTALEMBERT','79190','0574485963','serge.ABSIS@gmail.com',86),
		('AD0963485','M','RUSSEL','ADRIEN','568 CHEMIN DU BEAL','RIVERY','80136','0245532658','adrien.RUSSEL@gmail.com',48),
		('AD0963486','M','LEFONCE','CHARLES','176 CHEMIN DU JONQUET','ST LEGER LES AUTHIE','80560','0211554789','charles.LEFONCE@gmail.com',59),
		('AD0963487','MLLE',' SECHAN','MEGANE','34 BOULEVARD FOURNIOL','SEILLONS SOURCE D ARGENS','83470','0494785698','megane.SECHAN@gmail.com',8),
		('AD0963488','M','	LIBRE','MAX','43 RUE DE PONDICHERY','LE THOR','84250','0490225866','max.LIBRE@gmail.com',9),
		('AD0963489','M','LESAINT','CHARLES','87 RUE SIDI BRAHIM','VEDENE','84270','0490467982','charles.LESAINT@gmail.com',24),
		('AD0963490','M','CHOUMI','MICK','29 RUE DOCTEUR GAURAN','PUGET SUR ARGENS','83480','0494668855','mick.choumi@gmail.com',16),
		('AD0963491','MLLE','THIBAULT','CELINE','4 CITE GENIN','Muller','23230','0254154963','céline.Thibault@gmail.com',78),
		('AD0963492','MME','PELLERIN','YVETTE','37 AVENUE D LA SAMARITAINE','THIONVILLE','57100','0541246754','yvette.PELLERIN@gmail.com',32)
;

INSERT INTO exemplaires (id_exemplaire,numero_exemplaire,etat,id_documentaire,id_support_physique)
	VALUES
		(NULL,'INTSTL01','E',1,1),
		(NULL,'INTSTL02','L',1,1),
		(NULL,'INTSTL03','E',1,2),
		(NULL,'INTSTL04','L',1,2),

		(NULL,'INCEPT01','E',2,1),
		(NULL,'INCEPT02','L',2,1),
		(NULL,'INCEPT03','E',2,2),
		(NULL,'INCEPT04','L',2,2),

		(NULL,'AVGRS101','E',3,1),
		(NULL,'AVGRS102','L',3,1),
		(NULL,'AVGRS103','E',3,2),
		(NULL,'AVGRS104','L',3,2),

		(NULL,'JONWI101','E',4,1),
		(NULL,'JONWI102','L',4,1),
		(NULL,'JONWI103','E',4,2),
		(NULL,'JONWI104','L',4,2)
;

INSERT INTO localiser (id_documentaire,id_lieux)
	VALUES 
        (1,10),
		(2,10),
		(3,2),
		(4,10)
;

INSERT INTO  participer (id_documentaire,id_star,role)
	VALUES
		(1,1,'Acteur'),
		(1,2,'Acteur'),
		(2,3,'Acteur'),
		(2,4,'Acteur'),
		(3,5,'Acteur'),
		(3,6,'Acteur'),
		(4,7,'Acteur'),
		(4,8,'Acteur'),
		(1,9,'Realisateur'),
		(2,9,'Realisateur'),
		(3,10,'Realisateur'),
		(4,11,'Realisateur')
;

INSERT INTO locations (`date_depart`, `date_rendu`,id_exemplaire,id_adherent) 
	VALUES
		('2021-01-06','2021-01-08',1,21),
		('2021-01-10','2021-01-11',7,16),
		('2021-01-21','2021-01-24',3,4),
		('2021-02-03','2021-02-07',11,10),
		('2021-02-05','2021-02-10',13,9)
;

INSERT INTO telechargements ('date_telechargement',id_documentaire,id_adherent)
	VALUES
		('2021-01-16',1,7),
		('2021-01-24',2,20),
		('2021-02-04',4,11),
		('2021-02-07',4,8),
		('2021-02-11',3,2)
;

-- TODO --
-- ! l'insert 'passe' une fois sur deux avec ou sans '' sur les id
-- Sans cote
-- ('2021-01-16',1,7),

-- Avec cote
-- ('2021-01-16','1','7'),