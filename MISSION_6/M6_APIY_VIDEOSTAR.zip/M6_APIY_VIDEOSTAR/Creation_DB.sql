-- ******************************************** --
-- * MISSION 6                                  --
-- * GROUPE APIY                                --
-- * DATE 11/02/21                              -- 
-- ******************************************** --
-- * ENVIRONNEMENT                              --
-- * phpMyAdmin ver 5.0.2                       --
-- * MySQL ver 5.7.31                           --
-- * OS: Win10, Nav: Chrome, EDI: VSCODE 1.53.2 --
-- ******************************************** --
-- * CREATION DE LA BASE DE DONNEES VIDEOSTAR   --
-- * Création des tables                        --
-- ******************************************** --

-- * INITIALISATION DE LA BDD                   --

DROP DATABASE IF EXISTS videostar;
CREATE DATABASE videostar;
USE videostar;

-- *********** CREATION DES TABLES ***********  --

CREATE TABLE ADHERENTS(
   id_adherent INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
   numero_adherent CHAR(10) NOT NULL UNIQUE,
   civilite CHAR(4) NOT NULL,
   nom VARCHAR(56) NOT NULL,
   prenom VARCHAR(56) NOT NULL,
   adresse VARCHAR(56) NOT NULL,
   code_postal CHAR(6) NOT NULL,
   ville VARCHAR(56),
   tel CHAR(10),
   email VARCHAR(64),
   credits_restant DECIMAL(5,2),

   INDEX (nom, prenom)
);

CREATE TABLE STARS(
   id_star INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
   nom VARCHAR(56) NOT NULL,
   prenom VARCHAR(56) NOT NULL,

   INDEX (nom, prenom)
);

CREATE TABLE CATEGORIES(
   id_categorie INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
   libelle VARCHAR(56) NOT NULL DEFAULT 'new',

   INDEX (libelle)
);

CREATE TABLE LIEUX(
   id_lieux INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
   nom VARCHAR(56) NOT NULL UNIQUE,
   
   INDEX (nom)
);

CREATE TABLE SUPPORTS_PHYSIQUES(
   id_support_physique INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
   libelle VARCHAR(32) NOT NULL UNIQUE,
   prix_location_journalier DECIMAL(5,2),

   INDEX (libelle)
);

CREATE TABLE DOCUMENTAIRES(
   id_documentaire INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
   code_documentaire CHAR(6) NOT NULL UNIQUE,
   libelle VARCHAR(64) NOT NULL,
   annee SMALLINT,
   telechargeable BOOLEAN,
   prix_telechargement SMALLINT,
   id_categorie INT,

   FOREIGN KEY(id_categorie) REFERENCES CATEGORIES(id_categorie),

   FULLTEXT INDEX (libelle)
);

CREATE TABLE EXEMPLAIRES(
   id_exemplaire INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
   numero_exemplaire CHAR(8) NOT NULL,
   etat CHAR(1) NOT NULL,
   id_documentaire INT NOT NULL,
   id_support_physique INT NOT NULL,

   FOREIGN KEY(id_documentaire) REFERENCES DOCUMENTAIRES(id_documentaire),
   FOREIGN KEY(id_support_physique) REFERENCES SUPPORTS_PHYSIQUES(id_support_physique)
);

CREATE TABLE LOCATIONS(
   id_location INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
   date_depart DATE UNIQUE,
   date_rendu DATE UNIQUE,
   id_exemplaire INT NOT NULL,
   id_adherent INT NOT NULL,

   FOREIGN KEY(id_exemplaire) REFERENCES EXEMPLAIRES(id_exemplaire),
   FOREIGN KEY(id_adherent) REFERENCES ADHERENTS(id_adherent)
);

CREATE TABLE TELECHARGEMENTS(
   id_telechargement INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
   date_telechargement DATE UNIQUE,
   id_documentaire INT NOT NULL,
   id_adherent INT NOT NULL,

   FOREIGN KEY(id_documentaire) REFERENCES DOCUMENTAIRES(id_documentaire),
   FOREIGN KEY(id_adherent) REFERENCES ADHERENTS(id_adherent)
);

CREATE TABLE PARTICIPER(
   id_documentaire INT,
   id_star INT,
   role VARCHAR(56),
    
    PRIMARY KEY (id_documentaire, id_star),
    FOREIGN KEY(id_documentaire) REFERENCES DOCUMENTAIRES(id_documentaire),
    FOREIGN KEY(id_star) REFERENCES STARS(id_star),

    INDEX (role)
);

CREATE TABLE LOCALISER(
   id_documentaire INT,
   id_lieux INT,

    PRIMARY KEY (id_documentaire,id_lieux),
    FOREIGN KEY(id_documentaire) REFERENCES DOCUMENTAIRES(id_documentaire),
    FOREIGN KEY(id_lieux) REFERENCES LIEUX(id_lieux)
);
