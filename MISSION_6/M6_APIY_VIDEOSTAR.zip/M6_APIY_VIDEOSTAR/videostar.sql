-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1:3306
-- Généré le : lun. 15 fév. 2021 à 12:30
-- Version du serveur :  5.7.31
-- Version de PHP : 7.3.21

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `videostar`
--

-- --------------------------------------------------------

--
-- Structure de la table `adherents`
--

DROP TABLE IF EXISTS `adherents`;
CREATE TABLE IF NOT EXISTS `adherents` (
  `id_adherent` int(11) NOT NULL AUTO_INCREMENT,
  `numero_adherent` char(10) NOT NULL,
  `civilite` char(4) NOT NULL,
  `nom` varchar(56) NOT NULL,
  `prenom` varchar(56) NOT NULL,
  `adresse` varchar(56) NOT NULL,
  `code_postal` char(6) NOT NULL,
  `ville` varchar(56) DEFAULT NULL,
  `tel` char(10) DEFAULT NULL,
  `email` varchar(64) DEFAULT NULL,
  `credits_restant` decimal(5,2) DEFAULT NULL,
  PRIMARY KEY (`id_adherent`),
  UNIQUE KEY `numero_adherent` (`numero_adherent`),
  KEY `nom` (`nom`,`prenom`)
) ENGINE=InnoDB AUTO_INCREMENT=36 DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `adherents`
--

INSERT INTO `adherents` (`id_adherent`, `numero_adherent`, `civilite`, `nom`, `prenom`, `adresse`, `code_postal`, `ville`, `tel`, `email`, `credits_restant`) VALUES
(1, 'AD0963458', 'MME', 'DUCLO', 'SIMONE', '8 RUE DU PRE', '87700', 'ST PRIEST SOUS AIXE', '0587463145', 'simone.DUCLO@gmail.com', '120.00'),
(2, 'AD0963459', 'M', 'VERIN', 'STEPHANE', '122 RUE DU SAVRE', '87800', 'ST HILAIRE LES PLACES', '0536543247', 'stephane.VERIN@gmail.com', '5.00'),
(3, 'AD0963460', 'M', 'LEMOINE', 'LAURENT', '14 RUE DE MONSERRAT', '87800', 'LA ROCHE LABEILLE', '0596579212', 'laurent.LEMOINE@gmail.com', '34.00'),
(4, 'AD0963461', 'MME', 'DUPRE', 'SIMONE', '154 BOULEVARD CHATEAUVALLON', '88560', 'ST MAURICE SUR MOSELLE', '0476521589', 'simone.DUPRE@gmail.com', '124.00'),
(5, 'AD0963462', 'M', '	LEPINE', 'ADRIEN', '43 RUE AMIRAL CELLIER', '88600', 'CHAMP LE DUC', '0548745472', 'adrien.LEPINE@gmail.com', '21.00'),
(6, 'AD0963463', 'MLLE', 'VERGO', 'JUSTINE', '12 RUE DE OLIVADES', '89510', 'ETIGNY', '0563659214', 'justine.VERGO@gmail.com', '33.00'),
(7, 'AD0963464', 'M', 'PRUNEL', 'FREDERIC', '65 CHEMIN BONFANTE', '88500', 'JORXEY', '0582546975', 'frederic.PRUNEL@gmail.com', '68.00'),
(8, 'AD0963465', 'MLLE', 'ABSIS', 'AGNES', '8 AVENUE CHARLES GANTELME', '88500', 'REMICOURT', '0556986365', 'agnes.ABSIS@gmail.com', '97.00'),
(9, 'AD0963466', 'M', 'AXSON', 'NICOLAS', '97 RUE HONORE POURCHIER', '52500', 'GILLEY', '0165324652', 'nicolas.AXSON@gmail.com', '47.00'),
(10, 'AD0963467', 'MLLE', 'DESCHAMPS', 'CORINE', '107 AVENUE SYLVAIN THURIN', '35490', 'GAHARD', '0145215874', 'corine.DESCHAMPS@gmail.com', '88.00'),
(11, 'AD0963468', 'MME', 'ALONZO', 'AGNES', '3 RUE CHAMPOLLION', '60480', 'PUITS LA VALLEE', '0213265425', 'agnes.ALONZO@gmail.com', '65.00'),
(12, 'AD0963469', 'M', 'FERRY', 'VINCENT', '69 TRAVERSE JAINE', '01500', 'AMBERIEU EN BUGEY', '0152326536', 'vincent.FERRY@gmail.com', '47.00'),
(13, 'AD0963470', 'M', 'LAROUSSE', 'ROBERT', '225 AVENUE CHIARISOLI BEY', '19800', 'GIMEL LES CASCADES', '0195154256', 'robert.LAROUSSE@gmail.com', '100.00'),
(14, 'AD0963471', 'M', 'HAMILTON', 'LEWIS', '17 AVENUE ANDRE LE CHATELIER', '19800', 'GIMEL LES CASCADES', '0195185647', 'lewis.HAMILTON@gmail.com', '98.00'),
(15, 'AD0963472', 'M', 'GROSJEAN', 'ROMAIN', '6 IMPASSE PEROT', '21110', 'CESSEY SUR TILLE', '0254784573', 'romain.GROSJEAN@gmail.com', '64.00'),
(16, 'AD0963473', 'M', 'MARTIN', 'DOCK', '107 AVENUE COMMANDANT BERNARD', '21120', 'CRECEY SUR TILLE', '0254784539', 'dock.MARTIN@gmail.com', '72.00'),
(17, 'AD0963474', 'M', 'DESCHAMPS', 'PHIL', '3 TRAVERSE RICHARD', '55230', 'DUZEY', '0547896314', 'phil.DESCHAMPS@gmail.com', '45.00'),
(18, 'AD0963475', 'M', ' PREVERT', 'JEAN', '48 CHEMIN DE LA POUDRIERE', '55110', 'FONTAINES ST CLAIR', '0527398465', 'jean.PREVERT@gmail.com', '98.00'),
(19, 'AD0963476', 'MME', 'HUGO', 'VERONIQUE', '304 RUE CANROBERT', '55220', ' LES TROIS DOMAINES', '0542365658', 'veronique.HUGO@gmail.com', '36.00'),
(20, 'AD0963477', 'M', 'VETEL', 'SEB', '62 RUE EDMON HARANCOURT', '55300', 'LAMORVILLE', '0598746589', 'seb.VETEL@gmail.com', '47.00'),
(21, 'AD0963478', 'M', 'BOTTAS', 'VAL', '107 PLACE MARIUS CHAMPAGNE', '55190', 'MARSON SUR BARBOURE', '0514237845', 'val.BOTTAS@gmail.com', '98.00'),
(22, 'AD0963479', 'M', 'RICHARD', 'DANY', '1 RUE CLINCHAMP', '55120', 'RECICOURT', '0595857412', 'dany.RICHARD@gmail.com', '96.00'),
(23, 'AD0963480', 'M', 'PEREZ', 'SERGE', '59 AVENUE PIERRE RENAUDEL	LES SOUHESMES', '55220', ' RAMPONT', '0568362335', 'serge.PEREZ@gmail.com', '25.00'),
(24, 'AD0963481', 'M', 'NORRIS', 'LAURENT', '307 AVENUE JEAN RAMBAUD', '29430', 'TREFLEZ', '0248755699', 'laurent.NORRIS@gmail.com', '37.00'),
(25, 'AD0963482', 'M', 'TROCON', 'SEB', '5 IMPASSE ESTAMPE', '30520', 'ST MARTIN DE VALGALGUES', '0224155478', 'seb.TROCON@gmail.com', '12.00'),
(26, 'AD0963483', 'MME', 'ALONZO', 'JUSTINE', '97 LES PEPINIERES DU LAS', '74420', 'BOEGE', '0588614937', 'justine.ALONZO@gmail.com', '3.00'),
(27, 'AD0963484', 'M', 'ABSIS', 'SERGE', '8 LES PRIMEROSES', '79190', 'MONTALEMBERT', '0574485963', 'serge.ABSIS@gmail.com', '86.00'),
(28, 'AD0963485', 'M', 'RUSSEL', 'ADRIEN', '568 CHEMIN DU BEAL', '80136', 'RIVERY', '0245532658', 'adrien.RUSSEL@gmail.com', '48.00'),
(29, 'AD0963486', 'M', 'LEFONCE', 'CHARLES', '176 CHEMIN DU JONQUET', '80560', 'ST LEGER LES AUTHIE', '0211554789', 'charles.LEFONCE@gmail.com', '59.00'),
(30, 'AD0963487', 'MLLE', ' SECHAN', 'MEGANE', '34 BOULEVARD FOURNIOL', '83470', 'SEILLONS SOURCE D ARGENS', '0494785698', 'megane.SECHAN@gmail.com', '8.00'),
(31, 'AD0963488', 'M', '	LIBRE', 'MAX', '43 RUE DE PONDICHERY', '84250', 'LE THOR', '0490225866', 'max.LIBRE@gmail.com', '9.00'),
(32, 'AD0963489', 'M', 'LESAINT', 'CHARLES', '87 RUE SIDI BRAHIM', '84270', 'VEDENE', '0490467982', 'charles.LESAINT@gmail.com', '24.00'),
(33, 'AD0963490', 'M', 'CHOUMI', 'MICK', '29 RUE DOCTEUR GAURAN', '83480', 'PUGET SUR ARGENS', '0494668855', 'mick.choumi@gmail.com', '16.00'),
(34, 'AD0963491', 'MLLE', 'THIBAULT', 'CELINE', '4 CITE GENIN', '23230', 'Muller', '0254154963', 'céline.Thibault@gmail.com', '78.00'),
(35, 'AD0963492', 'MME', 'PELLERIN', 'YVETTE', '37 AVENUE D LA SAMARITAINE', '57100', 'THIONVILLE', '0541246754', 'yvette.PELLERIN@gmail.com', '32.00');

-- --------------------------------------------------------

--
-- Structure de la table `categories`
--

DROP TABLE IF EXISTS `categories`;
CREATE TABLE IF NOT EXISTS `categories` (
  `id_categorie` int(11) NOT NULL AUTO_INCREMENT,
  `libelle` varchar(56) NOT NULL DEFAULT 'new',
  PRIMARY KEY (`id_categorie`),
  KEY `libelle` (`libelle`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `categories`
--

INSERT INTO `categories` (`id_categorie`, `libelle`) VALUES
(6, 'action'),
(10, 'animation'),
(7, 'aventure'),
(11, 'biopic'),
(5, 'comédie'),
(8, 'documentaire'),
(12, 'drame'),
(13, 'fantastique'),
(9, 'frisson'),
(1, 'new'),
(14, 'peplum'),
(3, 'policier'),
(2, 'science-fiction'),
(4, 'thriller');

-- --------------------------------------------------------

--
-- Structure de la table `documentaires`
--

DROP TABLE IF EXISTS `documentaires`;
CREATE TABLE IF NOT EXISTS `documentaires` (
  `id_documentaire` int(11) NOT NULL AUTO_INCREMENT,
  `code_documentaire` char(6) NOT NULL,
  `libelle` varchar(64) NOT NULL,
  `annee` smallint(6) DEFAULT NULL,
  `telechargeable` tinyint(1) DEFAULT NULL,
  `prix_telechargement` smallint(6) DEFAULT NULL,
  `id_categorie` int(11) DEFAULT NULL,
  PRIMARY KEY (`id_documentaire`),
  UNIQUE KEY `code_documentaire` (`code_documentaire`),
  KEY `id_categorie` (`id_categorie`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `documentaires`
--

INSERT INTO `documentaires` (`id_documentaire`, `code_documentaire`, `libelle`, `annee`, `telechargeable`, `prix_telechargement`, `id_categorie`) VALUES
(1, 'INTSTL', 'Interstellar', 2014, 1, 5, NULL),
(2, 'INCEPT', 'Inception', 2010, 1, 5, NULL),
(3, 'AVGRS1', 'Avengers', 2012, 1, 5, NULL),
(4, 'JONWI1', 'John Wick 1', 2014, 1, 5, NULL);

-- --------------------------------------------------------

--
-- Structure de la table `exemplaires`
--

DROP TABLE IF EXISTS `exemplaires`;
CREATE TABLE IF NOT EXISTS `exemplaires` (
  `id_exemplaire` int(11) NOT NULL AUTO_INCREMENT,
  `numero_exemplaire` char(8) NOT NULL,
  `etat` char(1) NOT NULL,
  `id_documentaire` int(11) NOT NULL,
  `id_support_physique` int(11) NOT NULL,
  PRIMARY KEY (`id_exemplaire`),
  KEY `id_documentaire` (`id_documentaire`),
  KEY `id_support_physique` (`id_support_physique`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `exemplaires`
--

INSERT INTO `exemplaires` (`id_exemplaire`, `numero_exemplaire`, `etat`, `id_documentaire`, `id_support_physique`) VALUES
(1, 'INTSTL01', 'E', 1, 1),
(2, 'INTSTL02', 'L', 1, 1),
(3, 'INTSTL03', 'E', 1, 2),
(4, 'INTSTL04', 'L', 1, 2),
(5, 'INCEPT01', 'E', 2, 1),
(6, 'INCEPT02', 'L', 2, 1),
(7, 'INCEPT03', 'E', 2, 2),
(8, 'INCEPT04', 'L', 2, 2),
(9, 'AVGRS101', 'E', 3, 1),
(10, 'AVGRS102', 'L', 3, 1),
(11, 'AVGRS103', 'E', 3, 2),
(12, 'AVGRS104', 'L', 3, 2),
(13, 'JONWI101', 'E', 4, 1),
(14, 'JONWI102', 'L', 4, 1),
(15, 'JONWI103', 'E', 4, 2),
(16, 'JONWI104', 'L', 4, 2);

-- --------------------------------------------------------

--
-- Structure de la table `lieux`
--

DROP TABLE IF EXISTS `lieux`;
CREATE TABLE IF NOT EXISTS `lieux` (
  `id_lieux` int(11) NOT NULL AUTO_INCREMENT,
  `nom` varchar(56) NOT NULL,
  PRIMARY KEY (`id_lieux`),
  UNIQUE KEY `nom` (`nom`),
  KEY `nom_2` (`nom`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `lieux`
--

INSERT INTO `lieux` (`id_lieux`, `nom`) VALUES
(11, 'Angleterre'),
(9, 'Berlin'),
(7, 'Chicago'),
(10, 'Etats-Unis'),
(8, 'Londre'),
(5, 'Los-Angeles'),
(6, 'Lyon'),
(4, 'Marseille'),
(2, 'New-York'),
(1, 'Paris'),
(3, 'Washington');

-- --------------------------------------------------------

--
-- Structure de la table `localiser`
--

DROP TABLE IF EXISTS `localiser`;
CREATE TABLE IF NOT EXISTS `localiser` (
  `id_documentaire` int(11) NOT NULL,
  `id_lieux` int(11) NOT NULL,
  PRIMARY KEY (`id_documentaire`,`id_lieux`),
  KEY `id_lieux` (`id_lieux`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `localiser`
--

INSERT INTO `localiser` (`id_documentaire`, `id_lieux`) VALUES
(3, 2),
(1, 10),
(2, 10),
(4, 10);

-- --------------------------------------------------------

--
-- Structure de la table `locations`
--

DROP TABLE IF EXISTS `locations`;
CREATE TABLE IF NOT EXISTS `locations` (
  `id_location` int(11) NOT NULL AUTO_INCREMENT,
  `date_depart` date DEFAULT NULL,
  `date_rendu` date DEFAULT NULL,
  `id_exemplaire` int(11) NOT NULL,
  `id_adherent` int(11) NOT NULL,
  PRIMARY KEY (`id_location`),
  UNIQUE KEY `date_depart` (`date_depart`),
  UNIQUE KEY `date_rendu` (`date_rendu`),
  KEY `id_exemplaire` (`id_exemplaire`),
  KEY `id_adherent` (`id_adherent`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `locations`
--

INSERT INTO `locations` (`id_location`, `date_depart`, `date_rendu`, `id_exemplaire`, `id_adherent`) VALUES
(1, '2021-01-06', '2021-01-08', 1, 21),
(2, '2021-01-10', '2021-01-11', 7, 16),
(3, '2021-01-21', '2021-01-24', 3, 4),
(4, '2021-02-03', '2021-02-07', 11, 10),
(5, '2021-02-05', '2021-02-10', 13, 9);

-- --------------------------------------------------------

--
-- Structure de la table `participer`
--

DROP TABLE IF EXISTS `participer`;
CREATE TABLE IF NOT EXISTS `participer` (
  `id_documentaire` int(11) NOT NULL,
  `id_star` int(11) NOT NULL,
  `role` varchar(56) DEFAULT NULL,
  PRIMARY KEY (`id_documentaire`,`id_star`),
  KEY `id_star` (`id_star`),
  KEY `role` (`role`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `participer`
--

INSERT INTO `participer` (`id_documentaire`, `id_star`, `role`) VALUES
(1, 1, 'Acteur'),
(1, 2, 'Acteur'),
(2, 3, 'Acteur'),
(2, 4, 'Acteur'),
(3, 5, 'Acteur'),
(3, 6, 'Acteur'),
(4, 7, 'Acteur'),
(4, 8, 'Acteur'),
(1, 9, 'Realisateur'),
(2, 9, 'Realisateur'),
(3, 10, 'Realisateur'),
(4, 11, 'Realisateur');

-- --------------------------------------------------------

--
-- Structure de la table `stars`
--

DROP TABLE IF EXISTS `stars`;
CREATE TABLE IF NOT EXISTS `stars` (
  `id_star` int(11) NOT NULL AUTO_INCREMENT,
  `nom` varchar(56) NOT NULL,
  `prenom` varchar(56) NOT NULL,
  PRIMARY KEY (`id_star`),
  KEY `nom` (`nom`,`prenom`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `stars`
--

INSERT INTO `stars` (`id_star`, `nom`, `prenom`) VALUES
(2, 'Anne', 'Hathaway'),
(11, 'Chad', 'Stahelski'),
(9, 'Christopher', 'Nolan'),
(10, 'Joss', 'Whedon'),
(7, 'Keanu', 'Reeves'),
(8, 'Laurence', 'Fishburne'),
(3, 'Leonardo', 'DiCaprio'),
(1, 'McConaughey', 'Matthew'),
(5, 'Robert', 'Downey Jr'),
(6, 'Scarlett', 'Johansson'),
(4, 'Tom', 'Hardy');

-- --------------------------------------------------------

--
-- Structure de la table `supports_physiques`
--

DROP TABLE IF EXISTS `supports_physiques`;
CREATE TABLE IF NOT EXISTS `supports_physiques` (
  `id_support_physique` int(11) NOT NULL AUTO_INCREMENT,
  `libelle` varchar(32) NOT NULL,
  `prix_location_journalier` decimal(5,2) DEFAULT NULL,
  PRIMARY KEY (`id_support_physique`),
  UNIQUE KEY `libelle` (`libelle`),
  KEY `libelle_2` (`libelle`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `supports_physiques`
--

INSERT INTO `supports_physiques` (`id_support_physique`, `libelle`, `prix_location_journalier`) VALUES
(1, 'DVD', '3.00'),
(2, 'BLU-RAY', '4.00');

-- --------------------------------------------------------

--
-- Structure de la table `telechargements`
--

DROP TABLE IF EXISTS `telechargements`;
CREATE TABLE IF NOT EXISTS `telechargements` (
  `id_telechargement` int(11) NOT NULL AUTO_INCREMENT,
  `date_telechargement` date DEFAULT NULL,
  `id_documentaire` int(11) NOT NULL,
  `id_adherent` int(11) NOT NULL,
  PRIMARY KEY (`id_telechargement`),
  UNIQUE KEY `date_telechargement` (`date_telechargement`),
  KEY `id_documentaire` (`id_documentaire`),
  KEY `id_adherent` (`id_adherent`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `telechargements`
--

INSERT INTO `telechargements` (`id_telechargement`, `date_telechargement`, `id_documentaire`, `id_adherent`) VALUES
(1, '2021-01-16', 1, 7),
(2, '2021-01-24', 2, 20),
(3, '2021-02-04', 4, 11),
(4, '2021-02-07', 4, 8),
(5, '2021-02-11', 3, 2);

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `documentaires`
--
ALTER TABLE `documentaires` ADD FULLTEXT KEY `libelle` (`libelle`);

--
-- Contraintes pour les tables déchargées
--

--
-- Contraintes pour la table `documentaires`
--
ALTER TABLE `documentaires`
  ADD CONSTRAINT `documentaires_ibfk_1` FOREIGN KEY (`id_categorie`) REFERENCES `categories` (`id_categorie`);

--
-- Contraintes pour la table `exemplaires`
--
ALTER TABLE `exemplaires`
  ADD CONSTRAINT `exemplaires_ibfk_1` FOREIGN KEY (`id_documentaire`) REFERENCES `documentaires` (`id_documentaire`),
  ADD CONSTRAINT `exemplaires_ibfk_2` FOREIGN KEY (`id_support_physique`) REFERENCES `supports_physiques` (`id_support_physique`);

--
-- Contraintes pour la table `localiser`
--
ALTER TABLE `localiser`
  ADD CONSTRAINT `localiser_ibfk_1` FOREIGN KEY (`id_documentaire`) REFERENCES `documentaires` (`id_documentaire`),
  ADD CONSTRAINT `localiser_ibfk_2` FOREIGN KEY (`id_lieux`) REFERENCES `lieux` (`id_lieux`);

--
-- Contraintes pour la table `locations`
--
ALTER TABLE `locations`
  ADD CONSTRAINT `locations_ibfk_1` FOREIGN KEY (`id_exemplaire`) REFERENCES `exemplaires` (`id_exemplaire`),
  ADD CONSTRAINT `locations_ibfk_2` FOREIGN KEY (`id_adherent`) REFERENCES `adherents` (`id_adherent`);

--
-- Contraintes pour la table `participer`
--
ALTER TABLE `participer`
  ADD CONSTRAINT `participer_ibfk_1` FOREIGN KEY (`id_documentaire`) REFERENCES `documentaires` (`id_documentaire`),
  ADD CONSTRAINT `participer_ibfk_2` FOREIGN KEY (`id_star`) REFERENCES `stars` (`id_star`);

--
-- Contraintes pour la table `telechargements`
--
ALTER TABLE `telechargements`
  ADD CONSTRAINT `telechargements_ibfk_1` FOREIGN KEY (`id_documentaire`) REFERENCES `documentaires` (`id_documentaire`),
  ADD CONSTRAINT `telechargements_ibfk_2` FOREIGN KEY (`id_adherent`) REFERENCES `adherents` (`id_adherent`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
